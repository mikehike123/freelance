<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
require 'PHPMailer/PHPMailerAutoload.php';
error_reporting(E_ALL);



$isMailerActive=true;
$isNoError=true;
$errorMsg="";
if (!filter_var($_POST['InputEmail'], FILTER_VALIDATE_EMAIL)) {
    $errorMsg = "This ({$_POST['InputEmail']}) email address is not considered valid.";
    $isNoError=false;
    die("<h1>{$errorMsg}</h1>");
}
//
try {
        //die("<h1>stage 1</h1>");
        $mail = new PHPMailer(true);
        //die("<h1>stage 2</h1>");
        $mail->IsSMTP(); // Using SMTP.
        $mail->CharSet = 'utf-8';
        //$mail->SMTPDebug = 2; // Enables SMTP debug information - SHOULD NOT be active on production servers!
        $mail->SMTPAuth = false; // Enables SMTP authentication.
        $mail->Host = "relay-hosting.secureserver.net"; // SMTP server host.

        $mail->AddReplyTo('mike@mossycity.com', 'Me');
        $mail->SetFrom($_POST['InputEmail'], $_POST['InputName']);
        $mail->Subject = 'Request For Web Development';
        $mail->AltBody = 'To view the message, please use an HTML compatible email viewer!';
        $mail->MsgHTML($_POST['InputMessage']);
        
        if($isMailerActive)
        {
            $mail->Send();
        }
        else
        {
            try
            {
                $myfile = fopen("lastEmail.txt", "w");
                $results = serialize($mail);
                fwrite($myfile, $results);
                fclose($myfile);
                
                MailErr::Append("Email is not Enabled");
            
            } catch (Exception $e) {
                 MailErr::Append($e->errorMessage());
                //die($e->getMessage()); 
            }
            
        }
    } catch (phpmailerException $e) {
       MailErr::Append($e->errorMessage());
       // die($e->errorMessage()); 
    } catch (Exception $e) {
       // die($e->getMessage()); 
       MailErr::Append($e->errorMessage());
    }
    
    MailErr::Success();

    